package com.movieAndgame.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GameMemberDto {
	private String email;
	private String password;
	private String nickName;

}
