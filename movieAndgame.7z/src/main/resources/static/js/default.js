/**
 * 
 */

$(function(){
	
	$(".logo").on("click",function(){
		location.href="/movie/index";
	});
	
});
