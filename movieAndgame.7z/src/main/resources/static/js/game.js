/**
 * 
 */

$(function(){
	
	$(".logo").on("click",function(){
		location.href="/game/index";
	});
	
});