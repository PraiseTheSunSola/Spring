package com.movieAndgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieAndgameApplicationTests {

	@Test
	void contextLoads() {
	}

}
